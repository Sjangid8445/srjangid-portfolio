// Sticky Header

function toggleScrolled() {
    const selectBody = document.body;
    const selectHeader = document.getElementById('header');
    // Proceed if header has sticky/fixed/scroll-up-sticky class
    if (
        !selectHeader.classList.contains('sticky-top') &&
        !selectHeader.classList.contains('fixed-top') &&
        !selectHeader.classList.contains('scroll-up-sticky')
    ) return;
    // Add/remove .scrolled on body depending on scroll position
    if (window.scrollY > 100) {
        selectBody.classList.add('scrolled');
    } else {
        selectBody.classList.remove('scrolled');
    }
}
window.addEventListener('scroll', toggleScrolled);
window.addEventListener('load', toggleScrolled);


// Hero Section
const roles = ["Frontend Developer", "Web Designer", "Graphics Designer"];
let roleIndex = 0;
let charIndex = 0;
let typingSpeed = 150;
let erasingSpeed = 100;
let delayBetween = 1500;

const roleElement = document.getElementById("role");

function typeEffect() {
    if (charIndex < roles[roleIndex].length) {
        roleElement.textContent += roles[roleIndex].charAt(charIndex);
        charIndex++;
        setTimeout(typeEffect, typingSpeed);
    } else {
        setTimeout(eraseEffect, delayBetween);
    }
}

function eraseEffect() {
    if (charIndex > 0) {
        roleElement.textContent = roles[roleIndex].substring(0, charIndex - 1);
        charIndex--;
        setTimeout(eraseEffect, erasingSpeed);
    } else {
        roleIndex = (roleIndex + 1) % roles.length; // next word
        setTimeout(typeEffect, typingSpeed);
    }
}

// Start
document.addEventListener("DOMContentLoaded", function () {
    setTimeout(typeEffect, delayBetween);
});

// EmailJS
(function () {
    emailjs.init("nvXw25OiSEtTS_kjS");
})();

// Hire Form
document.getElementById("hireForm").addEventListener("submit", function (e) {
    e.preventDefault();



    emailjs.sendForm("service_jd3sm25", "template_52pf7zn", this)
        .then(() => {
            alert("✅ Thank you! Your hire request has been sent.");
            this.reset();
        }, (error) => {
            alert("❌ Failed to send: " + JSON.stringify(error));
        });
    bootstrap.Modal.getInstance(document.getElementById("hireModal")).hide();
});

// Call Form
document.getElementById("callForm").addEventListener("submit", function (e) {
    e.preventDefault();
    emailjs.sendForm("service_jd3sm25", "template_52pf7zn", this)
        .then(() => {
            alert("✅ Thank you! Your call request has been sent.");
            this.reset();
        }, (error) => {
            alert("❌ Failed to send: " + JSON.stringify(error));
        });
    bootstrap.Modal.getInstance(document.getElementById("callModal")).hide();
});


// // Hire Form
// document.getElementById("hireForm").addEventListener("submit", function (e) {
//     e.preventDefault();

//     const email = this.querySelector("input[name='email']").value;

//     // ✅ Company email restriction
//     if (!email.endsWith("@yourcompany.com")) {
//         alert("⚠️ Only company members can use this form!");
//         return;
//     }

//     // ✅ reCAPTCHA check
//     const response = grecaptcha.getResponse();
//     if (response.length === 0) {
//         alert("⚠️ Please verify reCAPTCHA!");
//         return;
//     }

//     // ✅ EmailJS send
//     emailjs.sendForm("service_jd3sm25", "template_52pf7zn", this)
//         .then(() => {
//             alert("✅ Thank you! Your hire request has been sent.");
//             this.reset();
//             grecaptcha.reset(); // reCAPTCHA reset
//             bootstrap.Modal.getInstance(document.getElementById("hireModal")).hide();
//         }, (error) => {
//             alert("❌ Failed to send: " + JSON.stringify(error));
//         });
// });

// // Call Form
// document.getElementById("callForm").addEventListener("submit", function (e) {
//     e.preventDefault();

//     const email = this.querySelector("input[name='email']").value;

//     // ✅ Company email restriction
//     if (!email.endsWith("@yourcompany.com")) {
//         alert("⚠️ Only company members can use this form!");
//         return;
//     }

//     // ✅ reCAPTCHA check
//     const response = grecaptcha.getResponse();
//     if (response.length === 0) {
//         alert("⚠️ Please verify reCAPTCHA!");
//         return;
//     }

//     // ✅ EmailJS send
//     emailjs.sendForm("service_jd3sm25", "template_52pf7zn", this)
//         .then(() => {
//             alert("✅ Thank you! Your call request has been sent.");
//             this.reset();
//             grecaptcha.reset(); // reCAPTCHA reset
//             bootstrap.Modal.getInstance(document.getElementById("callModal")).hide();
//         }, (error) => {
//             alert("❌ Failed to send: " + JSON.stringify(error));
//         });
// });


// Resume Btn Animation
const btn = document.getElementById("resumeBtn");
const span = btn.querySelector("span");

function changeText(newText) {
    span.classList.add("fade-out");

    setTimeout(() => {
        span.textContent = newText;
        span.classList.remove("fade-out");

        void span.offsetWidth;

        span.classList.add("fade-in");

        setTimeout(() => {
            span.classList.remove("fade-in");
        }, 300);
    }, 300);
}

btn.addEventListener("mouseenter", () => changeText("Download Now"));
btn.addEventListener("mouseleave", () => changeText("Resume"));

// Back To Top
const backToTop = document.querySelector(".back-to-top");

window.addEventListener("scroll", () => {
    if (window.scrollY > 200) {
        backToTop.style.display = "block";
    } else {
        backToTop.style.display = "none";
    }
});